          <div class="col-xl-6" id="product-view">
                                  @include($main_view_port_folder.'.weekly_product_view')
                                   </div>
                                   <div class="col-xl-6 col-sm-6" id="varient_view">
                                    @include($main_view_port_folder.'.weekly_varient_view')
                                   </div>