<div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">

                                <h4 class="card-title">{{$sub_title}}</h4>
                             
                                 <div class="">
                                <table id="datatable-buttons" class="table align-middle table-nowrap table-hover">
                                    <thead class="table-light">
                                        <tr>
                                            <th scope="col" style="width: 70px;">#</th>
                                        	<th>@lang('label.title')</th>
                                            <th>@lang('label.tag_line')</th>
                                            <th>@lang('label.descripiton')</th>
                                            <th>@lang('label.slider_for_page')</th>
                                            <th>@lang('label.action')</th>
                                        </tr>
                                    </thead>
                                    
                                   
                                </table>
                                </div>
                            </div>
                        </div>
                    </div> <!-- end col -->
                </div> <!-- end row -->
