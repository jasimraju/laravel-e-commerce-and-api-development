<div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">

                                <h4 class="card-title">{{$sub_title}}</h4>
                             

                               
                            </div>
                        </div>
                    </div> <!-- end col -->
                </div> <!-- end row 
